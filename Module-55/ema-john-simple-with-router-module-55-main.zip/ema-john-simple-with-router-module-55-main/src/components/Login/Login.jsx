import React from 'react';

const Login = () => {
    return (
        <div>
            <h2>Login coming sooon</h2>
        </div>
    );
};

export default Login;