import React from 'react';

const Inventory = () => {
    return (
        <div>
            <h3>Inventory page</h3>
        </div>
    );
};

export default Inventory;